class HogwartsCreditOracle {
    constructor() {
        this.provider = null;
        this.signer = null;
        this.contracts = {};
        this.currentAccount = null;
        
        // YOUR CONTRACT ADDRESSES
        this.contractAddresses = {
            oracle: '0xB7E3A25f56D7cF4d34A5011c606fFA6aEED8b866',
            nft: '0xD7845D9ABB6e3CDE2Af19f8cd39a48B42bC00A38',
            token: '0x2573B34247bA0908F13758d90D435036af6Fda39'
        };

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initializeApp());
        } else {
            this.initializeApp();
        }
    }

    async initializeApp() {
        console.log('🪄 Initializing Hogwarts Credit Oracle...');
        
        await this.waitForEthers();
        
        if (typeof ethers === 'undefined') {
            this.showError('Ethers.js failed to load. Please refresh the page.');
            return;
        }

        console.log('✅ Ethers.js loaded successfully');
        
        await this.setupEventListeners();
        await this.checkWalletConnection();
        this.displayContractAddresses();
        
        this.showMessage('✨ Hogwarts Credit Oracle is ready! Connect your wizard wallet to begin.');
    }

    async waitForEthers() {
        for (let i = 0; i < 50; i++) {
            if (typeof ethers !== 'undefined') return true;
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        return false;
    }

    showMessage(message) {
        this.showNotification(message, 'success');
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type = 'success') {
        const existing = document.querySelectorAll('.magic-notification');
        existing.forEach(el => el.remove());
        
        const notification = document.createElement('div');
        notification.className = `magic-notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">${type === 'success' ? '✨' : '⚠️'}</span>
                <span class="notification-text">${message}</span>
            </div>
        `;
        
        if (!document.querySelector('#notification-styles')) {
            const styles = document.createElement('style');
            styles.id = 'notification-styles';
            styles.textContent = `
                .magic-notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: linear-gradient(45deg, #1a1a4a, #2d1b69);
                    color: #f0e6d2;
                    padding: 15px 20px;
                    border-radius: 10px;
                    border: 2px solid #d4af37;
                    box-shadow: 0 5px 20px rgba(0,0,0,0.3);
                    z-index: 10000;
                    max-width: 400px;
                    font-family: 'Cinzel', serif;
                    animation: slideIn 0.3s ease-out;
                }
                .magic-notification.error {
                    background: linear-gradient(45deg, #4a1a1a, #691b2d);
                    border-color: #ff6b6b;
                }
                .notification-content {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(styles);
        }
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    async setupEventListeners() {
        this.removeEventListeners();
        
        document.getElementById('connectWallet').addEventListener('click', () => this.connectWallet());
        document.getElementById('refreshData').addEventListener('click', () => this.updateDashboard());
        document.getElementById('mintBadge').addEventListener('click', () => this.mintPowerBadge());
        document.getElementById('simulateRepayment').addEventListener('click', () => this.simulateRepayment());
        document.getElementById('simulateTrade').addEventListener('click', () => this.simulateTrade());
        document.getElementById('claimStreak').addEventListener('click', () => this.claimStreakReward());
        
        const streakBtn = document.getElementById('recordStreak');
        if (streakBtn) {
            streakBtn.addEventListener('click', () => this.recordDailyStreak());
        }
        
        if (window.ethereum) {
            window.ethereum.on('accountsChanged', (accounts) => {
                if (accounts.length > 0) {
                    this.currentAccount = accounts[0];
                    this.updateDashboard();
                } else {
                    this.handleDisconnect();
                }
            });

            window.ethereum.on('chainChanged', (chainId) => {
                window.location.reload();
            });
        }
    }

    removeEventListeners() {
        const buttons = [
            'connectWallet', 'refreshData', 'mintBadge', 
            'simulateRepayment', 'simulateTrade', 'claimStreak', 'recordStreak'
        ];
        
        buttons.forEach(id => {
            const btn = document.getElementById(id);
            if (btn) {
                const newBtn = btn.cloneNode(true);
                btn.parentNode.replaceChild(newBtn, btn);
            }
        });
    }

    displayContractAddresses() {
        document.getElementById('oracleAddress').textContent = this.shortenAddress(this.contractAddresses.oracle);
        document.getElementById('nftAddress').textContent = this.shortenAddress(this.contractAddresses.nft);
        document.getElementById('tokenAddress').textContent = this.shortenAddress(this.contractAddresses.token);
    }

    shortenAddress(address) {
        try {
            const formattedAddress = ethers.utils.getAddress(address);
            return `${formattedAddress.substring(0, 6)}...${formattedAddress.substring(formattedAddress.length - 4)}`;
        } catch (error) {
            return 'Invalid Address';
        }
    }

    async checkWalletConnection() {
        if (typeof window.ethereum !== 'undefined') {
            try {
                const accounts = await window.ethereum.request({ method: 'eth_accounts' });
                if (accounts.length > 0) {
                    await this.setupProvider();
                    this.currentAccount = accounts[0];
                    await this.updateDashboard();
                    this.updateWalletStatus('Connected', true);
                    this.enableActionButtons(true);
                }
            } catch (error) {
                console.error('Wallet connection check failed:', error);
            }
        }
    }

    enableActionButtons(enabled) {
        ['mintBadge', 'simulateRepayment', 'simulateTrade', 'claimStreak', 'refreshData', 'recordStreak'].forEach(id => {
            const btn = document.getElementById(id);
            if (btn) btn.disabled = !enabled;
        });
    }

    async connectWallet() {
        if (typeof window.ethereum === 'undefined') {
            this.showError('MetaMask not found. Please install MetaMask!');
            return;
        }

        try {
            await this.setupProvider();
            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            
            this.currentAccount = accounts[0];
            await this.updateDashboard();
            this.updateWalletStatus('Connected', true);
            this.enableActionButtons(true);
            this.showMessage('Wizard wallet connected successfully!');
            
        } catch (error) {
            console.error('Wallet connection failed:', error);
            if (error.code === 4001) {
                this.showError('Please connect your wallet to continue.');
            } else if (error.message.includes('already pending')) {
                this.showError('Connection request already pending. Please check MetaMask.');
            } else {
                this.showError('Connection failed: ' + error.message);
            }
        }
    }

    async setupProvider() {
        this.provider = new ethers.providers.Web3Provider(window.ethereum);
        this.signer = this.provider.getSigner();
        
        try {
            const oracleAddress = ethers.utils.getAddress(this.contractAddresses.oracle);
            const nftAddress = ethers.utils.getAddress(this.contractAddresses.nft);
            const tokenAddress = ethers.utils.getAddress(this.contractAddresses.token);
            
            console.log('Creating contracts with addresses:', { oracleAddress, nftAddress, tokenAddress });
            
            this.contracts.oracle = new ethers.Contract(
                oracleAddress,
                [
                    "function creditScores(address) view returns (uint256)",
                    "function getWizardRank(address) view returns (string)",
                    "function getCurrentStreak(address) view returns (uint256)",
                    "function recordLoanRepayment()",
                    "function recordSuccessfulTrade()",
                    "function recordStreakBonus()",
                    "function claimStreakReward()",
                    "function getLoanEligibility(address) view returns (string, uint256)",
                    "function getUserActivityLogs(address) view returns (tuple(string reason, int points, uint256 timestamp)[])",
                    "function initializeUser()"
                ],
                this.signer
            );
            
            this.contracts.nft = new ethers.Contract(
                nftAddress,
                [
                    "function mintPowerBadge()",
                    "function getMyBadgeLevel() view returns (string)",
                    "function balanceOf(address) view returns (uint256)",
                    "function upgradeBadge(address)"
                ],
                this.signer
            );

            this.contracts.token = new ethers.Contract(
                tokenAddress,
                [
                    "function balanceOf(address) view returns (uint256)",
                    "function symbol() view returns (string)",
                    "function claimInitialTokens()"
                ],
                this.signer
            );
            
        } catch (error) {
            console.error('Error setting up contracts:', error);
            throw new Error('Invalid contract addresses: ' + error.message);
        }
    }

    updateWalletStatus(status, isConnected) {
        document.getElementById('walletStatus').textContent = status;
        const btn = document.getElementById('connectWallet');
        if (btn) {
            btn.textContent = isConnected ? 'Disconnect' : 'Connect Wizard Wallet';
            btn.onclick = isConnected ? () => this.handleDisconnect() : () => this.connectWallet();
        }
    }

    handleDisconnect() {
        this.currentAccount = null;
        this.provider = null;
        this.signer = null;
        this.contracts = {};
        this.updateWalletStatus('Not Connected', false);
        this.enableActionButtons(false);
        this.resetDashboard();
        this.showMessage('Wizard wallet disconnected.');
    }

    resetDashboard() {
        document.getElementById('creditScore').textContent = '0';
        document.getElementById('wizardRank').textContent = 'First Year Student';
        document.getElementById('streakCount').textContent = '0';
        document.getElementById('walletAddress').textContent = '';
        document.getElementById('badgeDisplay').innerHTML = '<div class="badge bronze">No House Badge</div>';
        document.getElementById('loanInfo').innerHTML = 'Connect your wizard wallet to see loan eligibility...';
        document.getElementById('activityLog').innerHTML = 'No magical activities recorded yet...';
        
        const orb = document.getElementById('powerOrb');
        if (orb) {
            orb.style.background = 'linear-gradient(45deg, #8b4513, #d2691e, #f7ef8a)';
        }
    }

    async updateDashboard() {
        if (!this.currentAccount || !this.contracts.oracle) return;

        try {
            this.showLoadingState(true);
            
            let score = ethers.BigNumber.from(0);
            let rank = "First Year Student";
            let streak = ethers.BigNumber.from(0);

            try {
                const formattedAddress = ethers.utils.getAddress(this.currentAccount);
                score = await this.contracts.oracle.creditScores(formattedAddress);
                rank = await this.contracts.oracle.getWizardRank(formattedAddress);
                streak = await this.contracts.oracle.getCurrentStreak(formattedAddress);
            } catch (error) {
                console.log('Contract calls failed, using default values:', error.message);
            }
            
            document.getElementById('creditScore').textContent = score.toString();
            document.getElementById('wizardRank').textContent = rank;
            document.getElementById('streakCount').textContent = streak.toString();
            document.getElementById('walletAddress').textContent = `Wizard: ${this.currentAccount.substring(0, 10)}...`;
            
            await this.updateBadgeDisplay();
            await this.updateLoanEligibility();
            await this.updateActivityLog();
            this.updateOrbAppearance(score);
            
        } catch (error) {
            console.error('Dashboard update failed:', error);
            this.showError('Failed to update dashboard: ' + error.message);
        } finally {
            this.showLoadingState(false);
        }
    }

    async updateBadgeDisplay() {
        try {
            if (!this.currentAccount) return;
            
            const formattedAddress = ethers.utils.getAddress(this.currentAccount);
            const hasBadge = await this.contracts.nft.balanceOf(formattedAddress);
            const display = document.getElementById('badgeDisplay');
            if (!display) return;
            
            if (hasBadge.gt(0)) {
                const level = await this.contracts.nft.getMyBadgeLevel();
                const badgeClass = level.includes('Crystal') ? 'crystal' : 
                                 level.includes('Golden') ? 'gold' : 
                                 level.includes('Silver') ? 'silver' : 'bronze';
                display.innerHTML = `<div class="badge ${badgeClass}">${level}</div>`;
            } else {
                display.innerHTML = '<div class="badge bronze">No House Badge</div>';
            }
        } catch (error) {
            console.error('Badge update failed:', error.message);
        }
    }

    async updateLoanEligibility() {
        try {
            if (!this.currentAccount) return;
            
            const formattedAddress = ethers.utils.getAddress(this.currentAccount);
            const [loanType, amount] = await this.contracts.oracle.getLoanEligibility(formattedAddress);
            const loanAmount = ethers.utils.formatEther(amount);
            const info = document.getElementById('loanInfo');
            if (!info) return;
            
            info.innerHTML = amount.gt(0) ? 
                `<strong>${loanType}</strong><br>Max: ${parseFloat(loanAmount).toLocaleString()} WZT` :
                `<strong>${loanType}</strong><br>Mint a badge to start!`;
        } catch (error) {
            console.error('Loan info update failed:', error.message);
            const info = document.getElementById('loanInfo');
            if (info) {
                info.innerHTML = '<strong>Unable to fetch loan eligibility</strong><br>Check contract deployment';
            }
        }
    }

    async updateActivityLog() {
        try {
            if (!this.currentAccount) return;
            
            const formattedAddress = ethers.utils.getAddress(this.currentAccount);
            const logs = await this.contracts.oracle.getUserActivityLogs(formattedAddress);
            const container = document.getElementById('activityLog');
            if (!container) return;
            
            if (logs.length === 0) {
                container.innerHTML = 'No magical activities recorded yet...';
                return;
            }

            container.innerHTML = logs.slice(-5).reverse().map(log => `
                <div class="log-entry ${log.points > 0 ? 'positive' : 'negative'}">
                    <strong>${log.reason}</strong><br>
                    Points: ${log.points > 0 ? '+' : ''}${log.points}<br>
                    ${new Date(log.timestamp * 1000).toLocaleString()}
                </div>
            `).join('');
        } catch (error) {
            console.error('Activity log update failed:', error.message);
            const container = document.getElementById('activityLog');
            if (container) {
                container.innerHTML = 'Unable to load activity logs';
            }
        }
    }

    updateOrbAppearance(score) {
        const orb = document.getElementById('powerOrb');
        if (orb) {
            orb.style.background = score >= 50 ? 
                'linear-gradient(45deg, #f7ef8a, #d4af37, #ae8625)' : 
                'linear-gradient(45deg, #8b4513, #d2691e, #f7ef8a)';
        }
    }

    showLoadingState(show) {
        document.querySelectorAll('.action-btn, .magic-btn').forEach(btn => {
            btn.disabled = show;
        });
        if (show) document.getElementById('creditScore').textContent = '...';
    }

    async ensureUserInitialized() {
        try {
            await this.contracts.oracle.callStatic.recordLoanRepayment();
            return true;
        } catch (error) {
            const errorMessage = error?.data?.message || error?.message || JSON.stringify(error);
            
            if (errorMessage.includes("User not initialized")) {
                try {
                    this.showMessage('🪄 Initializing your wizard profile...');
                    const tx = await this.contracts.oracle.initializeUser();
                    this.showMessage('⏳ Waiting for confirmation...');
                    await tx.wait();
                    this.showMessage('✅ Wizard profile initialized!');
                    return true;
                } catch (initError) {
                    console.error('User initialization failed:', initError);
                    this.showError('Initialization failed: ' + (initError.reason || "Transaction rejected"));
                    return false;
                }
            }
            return true; 
        }
    }

    async mintPowerBadge() {
        if (!await this.ensureConnected()) return;

        try {
            this.showLoadingState(true);
            
            const hasBadge = await this.contracts.nft.balanceOf(this.currentAccount);
            if (hasBadge.gt(0)) {
                this.showMessage('You already have a House Badge!');
                return;
            }
            
            this.showMessage('🏰 Minting your House Badge...');
            const tx = await this.contracts.nft.mintPowerBadge();
            await tx.wait();
            
            await this.ensureUserInitialized();
            await this.updateDashboard();
            this.showMessage('🎉 House Badge minted successfully! Welcome to Hogwarts!');
            
        } catch (error) {
            console.error('Minting failed:', error);
            this.showError('Minting failed: ' + (error.reason || error.message));
        } finally {
            this.showLoadingState(false);
        }
    }

    async simulateRepayment() {
        if (!await this.ensureConnected()) return;

        try {
            this.showLoadingState(true);
            
            if (!await this.ensureUserInitialized()) {
                this.showError('Please initialize your profile to continue!');
                return;
            }
            
            this.showMessage('📜 Recording loan repayment...');
            const tx = await this.contracts.oracle.recordLoanRepayment();
            await tx.wait();
            await this.updateDashboard();
            this.showMessage('✅ Loan repayment recorded! +5 Wizard Power');
            
        } catch (error) {
            console.error('Repayment failed:', error);
            this.showError('Repayment failed: ' + (error.reason || error.message));
        } finally {
            this.showLoadingState(false);
        }
    }

    async simulateTrade() {
        if (!await this.ensureConnected()) return;

        try {
            this.showLoadingState(true);
            
            if (!await this.ensureUserInitialized()) {
                this.showError('Please initialize your profile to continue!');
                return;
            }
            
            this.showMessage('🧪 Recording potion trade...');
            const tx = await this.contracts.oracle.recordSuccessfulTrade();
            await tx.wait();
            await this.updateDashboard();
            this.showMessage('✅ Potion trade successful! +2 Wizard Power');
            
        } catch (error) {
            console.error('Trade failed:', error);
            this.showError('Trade failed: ' + (error.reason || error.message));
        } finally {
            this.showLoadingState(false);
        }
    }

    // FIXED: Properly catches "Minimum 3-day streak" error
    async recordDailyStreak() {
        if (!await this.ensureConnected()) return;

        try {
            this.showLoadingState(true);
            
            if (!await this.ensureUserInitialized()) {
                this.showError('Please initialize your profile to continue!');
                return;
            }

            this.showMessage('📅 Checking availability for daily streak bonus...');
            
            // Check via simulation first
            try {
                await this.contracts.oracle.callStatic.recordStreakBonus();
            } catch (simError) {
                // Get the error message from the nested structure
                let msg = simError?.reason || simError?.data?.message || simError?.message || JSON.stringify(simError);
                
                // If it's a revert error, dig into the data
                if (simError.error && simError.error.data && simError.error.data.message) {
                    msg = simError.error.data.message;
                }

                // CHECK SPECIFIC CONTRACT ERRORS
                if (msg.includes("Minimum 3-day streak")) {
                    throw new Error("⚠️ You need a 3-day streak! Perform Trades/Repayments on 3 different days first.");
                }
                
                if (msg.includes("wait") || msg.includes("24 hours")) {
                     throw new Error("⏳ You must wait 24 hours between check-ins!");
                }
                
                // Fallback for general reverts
                if (msg.includes("reverted")) {
                     throw new Error("⚠️ You cannot claim this yet. Build your streak by doing Trades or Repayments daily.");
                }
            }

            this.showMessage('📅 Recording streak bonus...');
            const tx = await this.contracts.oracle.recordStreakBonus();
            await tx.wait();
            
            await this.updateDashboard();
            this.showMessage('✅ Daily streak bonus recorded!');
            
        } catch (error) {
            console.error('Streak record failed:', error);
            // Display the friendly error message we threw above
            this.showError(error.message || 'Check-in failed');
        } finally {
            this.showLoadingState(false);
        }
    }

    async claimStreakReward() {
        if (!await this.ensureConnected()) return;

        try {
            this.showLoadingState(true);
            
            if (!await this.ensureUserInitialized()) {
                this.showError('Please initialize your profile to continue!');
                return;
            }
            
            this.showMessage('🎁 Claiming streak reward...');
            const tx = await this.contracts.oracle.claimStreakReward();
            await tx.wait();
            await this.updateDashboard();
            this.showMessage('💰 Streak reward claimed! 30 WZT tokens awarded.');
            
        } catch (error) {
            console.error('Reward claim failed:', error);
            if (error.message.includes('Minimum 3-day streak required')) {
                this.showError('You need at least a 3-day streak to claim rewards!');
            } else {
                this.showError('Reward claim failed: ' + (error.reason || error.message));
            }
        } finally {
            this.showLoadingState(false);
        }
    }

    async ensureConnected() {
        if (!this.currentAccount) {
            await this.connectWallet();
        }
        return !!this.currentAccount;
    }
}

window.addEventListener('load', () => {
    new HogwartsCreditOracle();
});